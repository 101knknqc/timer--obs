# Confidence Monitor — OBS Plugin

Dock natif OBS pour timers de présentation. Fond noir, chiffres énormes, 4 couleurs automatiques, 2 flashs avant transition, alertes sonores intégrées.

---

## Fonctionnalités

| Feature | Détail |
|---|---|
| **Timers illimités** | Ajoute / supprime des timers à la volée |
| **4 états de couleur** | Blanc → Jaune (moitié) → Orange (5 min) → Rouge (1 min) |
| **2 flashs avant transition** | Le timer clignote 2x avant de changer de couleur |
| **Compte en négatif** | Après 00:00 → -00:01, -00:02… |
| **Source OBS** | Met à jour une source Texte OBS avec la couleur exacte |
| **Son intégré** | Bip .wav compilé dans le .dll — aucun fichier externe requis |
| **Son perso** | Possibilité de choisir ton propre .wav par timer |
| **Persistance** | Timers sauvegardés entre les sessions |

---

## Option A — Compiler + générer le .exe avec NSIS (local)

### Prérequis

- Visual Studio 2022 Community — https://visualstudio.microsoft.com/fr/downloads/ (cocher "Développement Desktop C++")
- CMake 3.16+ — https://cmake.org/download/
- Qt 6.6+ avec QtMultimedia — https://www.qt.io/download-open-source
- NSIS 3.0+ — https://nsis.sourceforge.io/Download

### Compiler le plugin

```powershell
mkdir build && cd build

cmake .. `
  -G "Visual Studio 17 2022" -A x64 `
  -DQt6_DIR="C:\Qt\6.6.0\msvc2019_64\lib\cmake\Qt6" `
  -DOBS_INSTALL_DIR="C:\Program Files\obs-studio"

cmake --build . --config Release
```

### Générer le .exe installeur

```powershell
cd ..
& "C:\Program Files (x86)\NSIS\makensis.exe" installer.nsi
```

Le fichier `confidence-monitor-setup.exe` apparaît. Double-clic, next next next, OBS se relance automatiquement.

---

## Option B — GitHub Actions (zéro install, recommandé)

1. Push le projet sur GitHub
2. GitHub compile le .dll + génère le .exe automatiquement
3. Télécharge depuis **Actions → Artifacts**

Pour une release publique :
```bash
git tag v1.0.0 && git push origin v1.0.0
```

---

## Structure du projet

```
confidence-monitor/
├── CMakeLists.txt
├── installer.nsi                 ← script NSIS pour générer le .exe
├── LICENSE.txt
├── README.md
├── .github/workflows/build.yml   ← CI GitHub Actions
├── src/
│   ├── plugin-main.cpp
│   ├── confidence-monitor.hpp
│   ├── confidence-monitor.cpp
│   ├── confidence-monitor-dock.cpp
│   └── resources.qrc             ← alert.wav compilé dans le .dll
└── data/
    ├── alert.wav
    └── locale/en-US.ini
```

---

## Utilisation dans OBS

Après installation : `Affichage → Docks → Confidence Monitor`

**Couleurs appliquées à la source texte OBS :**

| Couleur | Moment |
|---|---|
| Blanc | Première moitié du temps |
| Jaune | Passé la moitié |
| Orange | Moins de 5 minutes |
| Rouge | Moins de 1 minute + temps négatif |

2 flashs rapides se produisent juste avant chaque changement de couleur. Le son joue à la moitié, à 5 min, à 1 min, et à 0.

---

## Dépannage

**Dock absent** → Vérifier `%APPDATA%\obs-studio\plugins\confidence-monitor\bin\64bit\confidence-monitor.dll`

**Source OBS pas mise à jour** → Le nom dans le champ doit correspondre exactement au nom de la source (sensible à la casse)

**Pas de son** → Vérifier que `Qt6Multimedia.dll` est présent dans le dossier OBS
